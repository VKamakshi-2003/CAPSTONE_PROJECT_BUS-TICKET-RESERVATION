package com.bus.busticketnew.repository;

import com.bus.busticketnew.model.Route;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RouteRepository extends JpaRepository<Route, Long> {
}
