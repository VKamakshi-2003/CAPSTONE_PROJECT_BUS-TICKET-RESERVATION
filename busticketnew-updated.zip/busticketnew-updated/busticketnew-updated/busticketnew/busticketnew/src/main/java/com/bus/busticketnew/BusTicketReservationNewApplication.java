package com.bus.busticketnew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusTicketReservationNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusTicketReservationNewApplication.class, args);
	}

}
